# 🔗 CRYSTALLINE SMART CONTRACT DEPLOYMENT GUIDE

## 📋 PREREQUISITES

1. **MetaMask Wallet** with MATIC tokens (~$5 worth for deployment)
2. **Remix IDE** (https://remix.ethereum.org) - free online Solidity IDE
3. **Polygon RPC** configured in MetaMask
4. **OpenZeppelin Contracts** (imported automatically in Remix)

---

## 🚀 STEP-BY-STEP DEPLOYMENT

### STEP 1: Set Up Polygon Network

1. Open MetaMask
2. Click network dropdown → Add Network
3. Enter Polygon Mainnet details:
   - **Network Name:** Polygon Mainnet
   - **RPC URL:** https://polygon-rpc.com/
   - **Chain ID:** 137
   - **Currency Symbol:** MATIC
   - **Block Explorer:** https://polygonscan.com/

4. Get MATIC tokens:
   - Buy on exchange (Coinbase, Binance)
   - Bridge from Ethereum using Polygon Bridge
   - Need ~$5 worth for deployment

---

### STEP 2: Deploy Contracts in Remix

1. **Open Remix:** https://remix.ethereum.org

2. **Create new file:** `Crystalline.sol`

3. **Paste the smart contract code** from `Crystalline-Contracts.sol`

4. **Install OpenZeppelin:**
   - Remix will auto-detect imports
   - Or manually install: Settings → Plugin Manager → Install "OpenZeppelin"

5. **Compile:**
   - Click "Solidity Compiler" tab (left sidebar)
   - Select compiler version: `0.8.19`
   - Click "Compile Crystalline.sol"
   - Wait for green checkmark

6. **Deploy:**

   **A. Deploy TruthToken:**
   - Click "Deploy & Run Transactions" tab
   - Environment: "Injected Provider - MetaMask"
   - Contract dropdown: Select "TruthToken"
   - Click "Deploy"
   - Confirm in MetaMask (~$0.50)
   - **COPY ADDRESS** → Save as `TRUTH_TOKEN_ADDRESS`

   **B. Deploy GasFeePool:**
   - Contract dropdown: Select "GasFeePool"
   - Click "Deploy"
   - Confirm in MetaMask (~$0.30)
   - **COPY ADDRESS** → Save as `GAS_POOL_ADDRESS`

   **C. Deploy CrystallineNetwork:**
   - Contract dropdown: Select "CrystallineNetwork"
   - Constructor parameters:
     - `_truthToken`: Paste `TRUTH_TOKEN_ADDRESS`
     - `_gasFeePool`: Paste `GAS_POOL_ADDRESS`
   - Click "Deploy"
   - Confirm in MetaMask (~$1.50)
   - **COPY ADDRESS** → Save as `CRYSTALLINE_ADDRESS`

---

### STEP 3: Configure Contracts

1. **Link GasFeePool to CrystallineNetwork:**
   - In Remix, find deployed "GasFeePool" contract
   - Expand functions
   - Find `setCrystallineContract`
   - Paste `CRYSTALLINE_ADDRESS`
   - Click "transact"
   - Confirm in MetaMask

2. **Transfer TruthToken Ownership:**
   - Find deployed "TruthToken" contract
   - Find `transferOwnership` function
   - Paste `CRYSTALLINE_ADDRESS`
   - Click "transact"
   - Confirm in MetaMask

---

### STEP 4: Fund the Gas Pool

Send MATIC to the GasFeePool address to start sponsoring user posts:

```
Recommended initial deposit: 100 MATIC (~$50)
This funds approximately 5,000 free posts
```

**How to deposit:**
- Send MATIC directly to `GAS_POOL_ADDRESS`
- Or call `deposit()` function with value
- Revenue from ads/donations goes here

---

## 🎯 TESTING THE CONTRACTS

### Create a Test Post

1. In Remix, find "CrystallineNetwork" contract
2. Expand `createPost` function
3. Enter parameters:
   ```
   encryptedContent: "U2FsdGVkX1..." (your encrypted post)
   ipfsHash: "QmXoypizjW3..." (IPFS hash)
   community: "gate"
   ```
4. Click "transact"
5. Check PolygonScan for transaction
6. Post ID returned = your first post!

### Verify a Post

1. Call `verifyPost(1)` - verifies post #1
2. Earns 5 TRUTH tokens
3. Original poster gets 5 TRUTH tokens too

---

## 💰 REVENUE MANAGEMENT

### Check Pool Balance

Call `getPoolStats()` on GasFeePool:
```
Returns:
- balance: Current MATIC in pool
- deposited: Total ever deposited
- spent: Total spent on gas
- availableForGas: Remaining for users (98%)
```

### Withdraw Your 2%

As platform owner:
```
Call: withdrawPlatformFee()
Withdraws: 2% of total deposits
To: Your deployer wallet
```

---

## 🔒 SECURITY NOTES

✅ **Posts are PERMANENT** - No delete function exists
✅ **Content is ENCRYPTED** - Only encrypted data on-chain
✅ **IPFS for media** - Files stored decentralized
✅ **No admin controls** - Truly censorship-resistant
✅ **Community governed** - Verification is decentralized

---

## 📊 CONTRACT ADDRESSES (Save These!)

After deployment, save all addresses:

```
TRUTH_TOKEN_ADDRESS: 0x...
GAS_POOL_ADDRESS: 0x...
CRYSTALLINE_ADDRESS: 0x...
```

**Add these to your website's config file!**

---

## 🌐 VERIFY CONTRACTS ON POLYGONSCAN

1. Go to https://polygonscan.com
2. Search your contract address
3. Click "Contract" tab → "Verify and Publish"
4. Select compiler version: 0.8.19
5. Paste contract code
6. Submit

Makes contracts publicly auditable!

---

## 💡 NEXT STEPS

1. ✅ Deploy contracts
2. ✅ Fund gas pool
3. ✅ Update website with contract addresses
4. ✅ Test posting from website
5. ✅ Launch to community!

---

## 🆘 TROUBLESHOOTING

**"Insufficient funds"**
→ Need more MATIC in wallet

**"Transaction failed"**
→ Increase gas limit in MetaMask

**"Contract not deployed"**
→ Check network is Polygon (137)

**"Can't verify post"**
→ Already verified that post

---

## 📞 SUPPORT

Contract issues? Check:
- PolygonScan transaction details
- Remix console for errors
- MetaMask activity log

---

**YOU'RE READY TO LAUNCH! 🚀**

These contracts make Crystalline truly unstoppable.
Once deployed, NOBODY can censor the truth.

💎 CRYSTALLINE - TRUTH ON BLOCKCHAIN 💎
